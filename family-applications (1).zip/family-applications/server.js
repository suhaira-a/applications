require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.ANTHROPIC_API_KEY;

if (!API_KEY) {
  console.warn('Warning: ANTHROPIC_API_KEY is not set. Copy .env.example to .env and add your key.');
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/generate', async (req, res) => {
  try {
    const { childName, childClass, schoolName, parentName, request, lang } = req.body;

    if (!request || !request.trim()) {
      return res.status(400).json({ error: 'Please describe what the application is for.' });
    }

    let langInstruction;
    if (lang === 'english') {
      langInstruction = 'Write the entire application in formal English.';
    } else if (lang === 'urdu') {
      langInstruction = 'Write the entire application in formal Urdu, using proper Urdu script.';
    } else {
      langInstruction = 'Detect the language the parent used in their request (English, Urdu, or Roman Urdu / a mix). If it is Urdu or Roman Urdu, write the application in formal Urdu script. Otherwise write it in formal English.';
    }

    const today = new Date().toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    const systemPrompt = `You write formal, ready-to-submit school/institutional applications on behalf of a parent, based on a short informal description of what they need. Output ONLY the finished application text, nothing else — no preamble, no explanation, no markdown formatting, no quotation marks around it.

Follow the correct real-world convention for a formal application letter (school leave, fee concession, TC request, medical excuse, etc):
- Start with the date: ${today} (translate/format naturally if writing in Urdu)
- A proper salutation to the recipient (e.g. "The Principal," and the school name if given, or "جناب پرنسپل صاحب" for Urdu)
- A clear subject line stating the purpose (e.g. "Subject: Application for Leave" / "موضوع: درخواستِ رخصت")
- A respectful, concise body that states who the application is for (child's name and class if given), the specific request, and a brief reason, phrased politely and naturally — not robotic
- A polite closing (e.g. "Yours sincerely," / "خاکسار")
- Signed by the parent's name if given, otherwise leave a blank line for a signature

${langInstruction}

Keep the tone warm but formal and respectful, as is standard for these letters. Keep it concise — 80 to 150 words in the body. Do not invent facts not given (like specific dates) unless the parent mentioned them — if a leave duration or date isn't specified, phrase it naturally without inventing exact dates.`;

    const userContent = `Child's name: ${childName || '(not given)'}
Class/grade: ${childClass || '(not given)'}
School name: ${schoolName || '(not given)'}
Parent/guardian signing: ${parentName || '(not given)'}

What the parent needs (written in their own words, possibly informal or mixed language):
"""${request}"""`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: 'user', content: userContent }]
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('Anthropic API error:', response.status, errText);
      return res.status(502).json({ error: 'The AI service returned an error. Please try again.' });
    }

    const data = await response.json();
    const textBlock = (data.content || []).find(b => b.type === 'text');
    const letterText = textBlock ? textBlock.text.trim() : '';

    if (!letterText) {
      return res.status(502).json({ error: 'No content was returned. Please try again.' });
    }

    res.json({ letter: letterText });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on the server.' });
  }
});

app.listen(PORT, () => {
  console.log(`Family Applications running at http://localhost:${PORT}`);
});
