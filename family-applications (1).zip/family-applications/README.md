# Family Applications

A small bilingual (English/Urdu) tool that turns a short, informal description of what's needed into a formal, ready-to-send application — for school leave, fee requests, and similar letters.

## How it's structured

- `server.js` — a small Express server. Holds your Anthropic API key and forwards requests to Claude. Your key never reaches the browser.
- `public/index.html` — the whole frontend (HTML, CSS, JS in one file). Calls `/api/generate` on your own server.
- `.env` — where your API key lives (you create this from `.env.example`, it's gitignored-worthy and never sent to the browser).

## Setup (in VS Code)

1. Open this folder in VS Code.
2. Make sure Node.js is installed (v18 or later — check with `node -v` in the terminal). Node 18+ has built-in `fetch`, which `server.js` uses.
3. Open a terminal in VS Code (`` Ctrl+` ``) and install dependencies:
   ```
   npm install
   ```
4. Copy the environment template and add your API key:
   ```
   cp .env.example .env
   ```
   Then open `.env` and paste in your key from https://console.anthropic.com/settings/keys:
   ```
   ANTHROPIC_API_KEY=sk-ant-...
   ```
5. Start the server:
   ```
   npm start
   ```
6. Open http://localhost:3000 in your browser.

Use `npm run dev` instead of `npm start` while you're editing — it restarts automatically when you save a file.

## Deploying it for real (so your mom can use it from her phone)

Right now this only runs on your own machine. To make it a real link she can open:

1. Push this folder to a GitHub repo (make sure `.env` is in `.gitignore` — don't commit your key).
2. Deploy it on a host that runs Node servers, e.g. Render, Railway, or Fly.io (all have free tiers). Point it at `server.js` as the start command.
3. Add `ANTHROPIC_API_KEY` as an environment variable in that host's dashboard, not in the code.
4. You'll get a public URL — bookmark it on her phone's home screen so it opens like an app.

## Customizing

- The formatting rules for the letter (date, salutation, subject line, tone) live in the `systemPrompt` string in `server.js` — edit that if you want a different tone or structure.
- Colors and fonts are CSS variables at the top of `public/index.html`'s `<style>` block.
- To add more fields (e.g. a saved history of past applications), you'd extend the form in `index.html` and pass the new fields through in the `fetch('/api/generate', ...)` call and in `server.js`.
